<?php
echo "Server Hostname is:"; echo gethostname();
?>

