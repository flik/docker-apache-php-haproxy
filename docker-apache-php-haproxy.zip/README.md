# docker-apache-php-haproxy

Simple Apache and PHP application with HAPROXY Setup in Docker

USAGE: docker-compose up --build -d 

This will spin up 3 web php container and an HAProxy Conatiner
